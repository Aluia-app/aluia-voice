# Aluia Voice Demo

Demo con microfono sempre attivo + sintesi vocale.
