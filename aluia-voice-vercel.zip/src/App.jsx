
import VoiceDemo from './VoiceDemo'
function App() {
  return <VoiceDemo />
}
export default App
